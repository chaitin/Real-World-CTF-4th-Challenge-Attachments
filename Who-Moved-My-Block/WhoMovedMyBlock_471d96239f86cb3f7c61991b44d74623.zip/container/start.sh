#!/bin/sh
nbd-server 0.0.0.0:10809 /rootfs.ext2
sleep infinity;
